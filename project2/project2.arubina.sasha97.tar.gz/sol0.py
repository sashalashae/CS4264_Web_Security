print  "arubina\0AAA+"
